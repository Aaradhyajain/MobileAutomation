# Mobile Automation Framework

This is a mobile automation framework built using Java, Maven, and Appium for testing mobile applications.

## Prerequisites

Before running the tests, ensure you have the following installed:

- Java 11 or above
- Maven 3 or above
- Appium 2 or above
- Mobile device emulator or real device connected

## Install Dependencies:
**mvn clean install**


## Running Tests
**mvn test -Pstart**
