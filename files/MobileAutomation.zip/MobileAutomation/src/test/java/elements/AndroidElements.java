package elements;

import io.appium.java_client.AppiumBy;
import org.openqa.selenium.By;

public interface AndroidElements {
    //Google Pixel Settings > Battery
    By Battery = AppiumBy.xpath("//android.widget.TextView[@resource-id=\"android:id/title\" and @text=\"Battery\"]");
}
