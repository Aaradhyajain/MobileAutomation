package mobileRun;

import elements.AndroidElements;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import util.MobileUtils;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class SettingsAppAutomation implements AndroidElements {
    AppiumDriver driver;
    DesiredCapabilities capabilities;
    WebDriverWait wait;

    @BeforeClass
    public void setup() throws MalformedURLException {
        capabilities = new DesiredCapabilities();
        capabilities.setCapability("appium:udid", "emulator-5554");
        capabilities.setCapability("appium:platformName", "Android");
        capabilities.setCapability("appium:automationName", "uiautomator2");

        //Settings App Package & Activity Details for Google Pixel
        capabilities.setCapability("appium:appPackage", "com.android.settings");
        capabilities.setCapability("appium:appActivity", "com.android.settings.Settings");

        //Initializing The Android Driver
        driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        System.out.println("Session Created, Session Id: "+driver.getSessionId());
    }

    @Test
    public void test() {
        //Settings App is Opened
        MobileUtils.screenshot(driver,"Pixel");
        //Clicking on Battery from Settings List
        System.out.println("Clicking on Battery");
        wait.until(ExpectedConditions.presenceOfElementLocated(Battery)).click();
        MobileUtils.sleep(3);
        MobileUtils.screenshot(driver,"Pixel");
    }

    @AfterClass
    public void tearDown() {
        //Closing The Session
        driver.quit();
    }
}
